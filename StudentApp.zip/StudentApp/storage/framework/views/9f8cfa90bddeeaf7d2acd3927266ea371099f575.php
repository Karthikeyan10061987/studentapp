<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Add Studnet</div>

                <div class="card-body">
                    <div class="content">
                        <?php echo Form::open(array('route'=>'student.store')); ?> 
                            <div class="form-group">
                                <?php echo Form::label('student_name','Stud Name'); ?>

                                <?php echo Form::text('student_name', null, ['calss'=>'form-control']); ?>

                            </div>

                            <div class="form-group">
                                <?php echo Form::label('nationality','Nationality '); ?>

                                <?php echo Form::text('nationality', null, ['calss'=>'form-control']); ?>

                            </div>

                            <div class="form-group">
                                <?php echo Form::label('phone_no','Phone No.'); ?>

                                <?php echo Form::text('phone_no', null, ['calss'=>'form-control']); ?>

                            </div>

                            <div class="form-group">
                                <?php echo Form::label('dob','Birth Date'); ?>

                                <?php echo Form::text('dob', null, ['calss'=>'form-control']); ?>

                            </div>
                               

                            <div class="form-group">
                                <?php echo Form::button('create',['type'=>'submit','class'=>'btn btn-primary']); ?>

                                
                            </div>

                        <?php echo Form::close(); ?>

                    </div>
                    <?php if( count( $errors ) > 0 ): ?>
                        <ul class="aler alert-danger">

                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>