@extends('layouts.app')
@section('content')


<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit Detail</div>

                <div class="card-body">
                    <div class="content">
                        {!! Form::model($student, array('route'=>['student.update',$student->id], 'method'=>'PUT')) !!} 
                            <div class="form-group">
                                {!! Form::label('student_name','Stud Name')!!}
                                {!!Form::text('student_name', null, ['calss'=>'form-control'])!!}
                            </div>

                            <div class="form-group">
                                {!! Form::label('nationality','Nationality ')!!}
                                {!!Form::text('nationality', null, ['calss'=>'form-control'])!!}
                            </div>

                            <div class="form-group">
                                {!! Form::label('phone_no','Phone No.')!!}
                                {!!Form::text('phone_no', null, ['calss'=>'form-control'])!!}
                            </div>

                            <div class="form-group">
                                {!! Form::label('dob','Birth Date')!!}
                                {!!Form::text('dob', null, ['calss'=>'form-control'])!!}
                            </div>
                               

                            <div class="form-group">
                                {!! Form::button('Update',['type'=>'submit','class'=>'btn btn-primary'])!!}
                                
                            </div>

                        {!! Form::close() !!}
                    </div>
                    @if ( count( $errors ) > 0 )

                        @foreach($errors->all() as $error)
                            {{$error}}
                        @endforeach
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

