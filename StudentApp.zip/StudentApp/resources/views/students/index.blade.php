
@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Student Details </div>
               
                <div class="card-body">
                    <div class="content">
                        @if(session()->has('message'))
                            <div class="alert alert-success">
                                {{ session()->get('message') }}
                            </div>
                        @endif

                         {{link_to_route('student.create','Add student', null, ['class'=>'btn btn-primary'])}} </br>
                        <table class="table">
                            <tr>
                                <th>Name</th>
                                <th>Nationality</th>
                                <th>Phone no</th>
                                <th>DOB</th>
                                <th>Action</th>
                            </tr>
                            @foreach($students as $student)
                            <tr>
                                <td>{{$student->student_name}}</td>
                                <td>{{$student->nationality}}</td>
                                <td>{{$student->phone_no}}</td>
                                <td>{{$student->dob}}</td>
                                <td>
                                    {!! Form::open(array('route'=>['student.destroy', $student->id], 'method'=>'DELETE')) !!}

                                    {{link_to_route('student.edit','Edit',[$student->id],['class'=>'btn btn-success']) }}
                                    |
                                 

                                        {!! Form::button('delete', ['class'=>'btn btn-danger','type'=>'submit'])!!}

                                    {!! Form::close() !!}
                                </td>
                            </tr>
                            @endforeach
                        </table>    
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
@endsection
<!-- Bootstrap core JavaScript

================================================= -->

<!-- Placed at the end of the document so the pages load faster -->

<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>



<!-- Bootstrap core JavaScript

================================================= -->

<!-- Placed at the end of the document so the pages load faster -->

<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

