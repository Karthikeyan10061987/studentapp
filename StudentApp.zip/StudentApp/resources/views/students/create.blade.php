@extends('layouts.app')
@section('content')


<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Add Studnet</div>

                <div class="card-body">
                    <div class="content">
                        {!! Form::open(array('route'=>'student.store')) !!} 
                            <div class="form-group">
                                {!! Form::label('student_name','Stud Name')!!}
                                {!!Form::text('student_name', null, ['calss'=>'form-control'])!!}
                            </div>

                            <div class="form-group">
                                {!! Form::label('nationality','Nationality ')!!}
                                {!!Form::text('nationality', null, ['calss'=>'form-control'])!!}
                            </div>

                            <div class="form-group">
                                {!! Form::label('phone_no','Phone No.')!!}
                                {!!Form::text('phone_no', null, ['calss'=>'form-control'])!!}
                            </div>

                            <div class="form-group">
                                {!! Form::label('dob','Birth Date')!!}
                                {!!Form::text('dob', null, ['calss'=>'form-control'])!!}
                            </div>
                               

                            <div class="form-group">
                                {!! Form::button('create',['type'=>'submit','class'=>'btn btn-primary'])!!}
                                
                            </div>

                        {!! Form::close() !!}
                    </div>
                    @if ( count( $errors ) > 0 )
                        <ul class="aler alert-danger">

                            @foreach($errors->all() as $error)
                                <li>{{$error}}</li>
                            @endforeach
                         </ul>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

